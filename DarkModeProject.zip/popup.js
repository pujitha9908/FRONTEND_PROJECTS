document.addEventListener("DOMContentLoaded", () => {
    const toggleBtn = document.querySelector(".button");
    const circle = document.querySelector(".circle");

    // Load saved theme from JSON (localStorage)
    let currentMode = localStorage.getItem("theme") || "light";

    // Apply saved mode
    if (currentMode === "dark") {
        document.body.classList.add("dark-mode");
        circle.style.transform = "translateX(100%)";
    }

    // Toggle button click
    toggleBtn.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");

        if (document.body.classList.contains("dark-mode")) {
            circle.style.transform = "translateX(100%)";
            localStorage.setItem("theme", "dark");
        } else {
            circle.style.transform = "translateX(0)";
            localStorage.setItem("theme", "light");
        }
    });
});